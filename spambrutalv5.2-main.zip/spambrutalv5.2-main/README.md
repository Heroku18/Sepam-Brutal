# SPAM BRUTAL V5.2 (Whatsapp,SMS)
```
lebih brutal dengan otp terbanyak
1 hari bisa ribuan pesan
```
> Script ini sewaktu-waktu bisa jadi limit ataupun coid bisa hubungi creator
## CARA INSTALL?
```
$ termux-setup-storage
$ apt upgrade
$ apt update
$ pkg update
$ pkg upgrade
$ pkg install jq
$ pkg install pip
$ pkg install git
$ pkg install curl
$ pkg install python
$ pkg install python2
$ pkg install python3
$ pip install requests
$ pip install bs4
$ pip install keyboard
$ git clone 
$ cd spambrutalv3
$ ls
$ python bot.py
```
## Support Me On
<br>
<b>• [Youtube()</b>
</br>
